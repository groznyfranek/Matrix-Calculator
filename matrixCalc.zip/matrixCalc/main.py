from calculator import Calculator

if __name__ == '__main__':
    program = Calculator('570x240', "Matrix Calculator")
    program.run()
